# Operations with dgs files
from numpy import zeros
from tqdm import tqdm


def readdgs(fname):
    with open(fname) as f:
        # read header
        ni, nj, nk = list(map(int, f.readline().split()))
        x = list(map(float, f.readline().split()))
        y = list(map(float, f.readline().split()))
        z = list(map(float, f.readline().split()))
        ne = int(f.readline())
        # read data
        a = zeros((ni - 1, nj - 1, nk - 1))
        for k in tqdm(list(range(ne))):
            vals = f.readline().split()
            ti, i, j, k = list(map(int, vals[0:4]))
            vals = list(map(float, vals[4:]))
            a[i - 1, j - 1, k - 1] = sum(vals)
        return x, y, z, a


def c_to_i(xmin, xmax, N, x):
    """
    xmin, xmax -- mesh baoundary, N -- number of mesh elements (not boundaries)
    x -- center's coordinate, which index to compute.

    returns i -- index of the mesh element, where x is located, i from 0 to N-1

        x = xmin + dx*i + dx/2, where dx = (xmax - xmin )/N

    exact expression for i:

        i = (x - dx/2 - xmin) / dx
        i = (x - xmin)/dx - 0.5

    Python truncates the deximal part when converting from float to integer.
    Thus, assuming that x always above xmin:

        0 < (x - xmin)/dx < 1.0   for x in the 1-st mesh element
        i < (x - xmin)/dx < i + 1 for x in the i-th mesh element

    thus, converting (x - xmin)/dx to integer gives the zero-based mesh index.
    """
    dx = (xmax - xmin)/N
    ii = (x - xmin) / dx
    return int(ii)


def readdgs_old(fname):
    with open(fname) as f:
        # read header
        tokens = f.readline().split()
        xmin, xmax = list(map(float, tokens[0:2]))
        ymin, ymax = list(map(float, tokens[3:5]))
        zmin, zmax = list(map(float, tokens[6:8]))
        xn, yn, zn, n = list(map(int, tokens[2::3]))

        dx = (xmax - xmin) / xn
        dy = (ymax - ymin) / yn
        dz = (zmax - zmin) / zn
        dv = dx * dy * dz

        x = [xmin + i*dx for i in range(xn+1)]
        y = [ymin + i*dy for i in range(yn+1)]
        z = [zmin + i*dz for i in range(zn+1)]

        # read data
        a = zeros((xn, yn, zn))
        for k in tqdm(list(range(n))):
            vals = f.readline().split()
            xi, yi, zi = list(map(float, vals[0:3]))
            i = c_to_i(xmin, xmax, xn, xi)
            j = c_to_i(ymin, ymax, yn, yi)
            k = c_to_i(zmin, zmax, zn, zi)

            # check coordinate to index conversion
            assert abs(xi - x[i]) < 0.01
            assert abs(yi - y[j]) < 0.01
            assert abs(zi - z[k]) < 0.01
            vals = list(map(float, vals[3:]))
            a[i, j, k] = sum(vals) * dv

        return x, y, z, a

if __name__ == '__main__':
    from sys import argv
    x, y, z, a = readdgs(argv[1])
    print(len(x), len(y), len(z), a.shape)
